use CS157A_AptDatabase;


LOAD DATA INFILE 'C:\\xampp\\htdocs\\BlueSwift\\SQL_Files\\Suite.csv' INTO TABLE Suite FIELDS TERMINATED BY ',' (roomSharing,price,specifications,petsAllowed,numberOfRooms);
