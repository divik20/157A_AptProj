Select * from Suite s JOIN apthassuites h ON h.aptLongitude = -122.432936 AND h.aptLatitude = 37.783028 AND s.suiteId = h.suiteId ORDER BY `h`.`suiteId` ASC

//with tenant info

Select
    s.suiteId,
    s.roomSharing,
    s.price,
    s.specifications,
    s.petsAllowed,
    s.numberOfRooms,
    t.name AS tenantName,
    t.phoneNumber,
    t.description
FROM suite s
INNER JOIN apthassuites h
ON h.aptLongitude = -122.432936 AND h.aptLatitude = 37.783028 AND s.suiteId = h.suiteId
JOIN tenanthassuite x
ON x.suiteId = s.suiteId
JOIN tenant t
ON x.tenPhoneNum = t.phoneNumber
ORDER BY `h`.`suiteId` ASC


Getting just Tenants in suite:
Select t.name,t.phoneNumber,t.description FROM tenant t
    JOIN tenanthassuite x
    ON x.suiteId = 40 AND x.tenPhoneNum = t.phoneNumber
    ORDER BY t.name ASC


    SELECT * FROM apartment
    JOIN apthassuites ON apartment.longitude = apthassuites.aptLongitude AND apartment.latitude = apthassuites.aptLatitude
    JOIN suite ON apthassuites.suiteId = suite.suiteId
    where apartment.city= "San Jose" AND apartment.state = "CA" AND suite.roomSharing = true


SELECT * FROM Suite WHERE suite.price >=10 AND suite.price <=3000
